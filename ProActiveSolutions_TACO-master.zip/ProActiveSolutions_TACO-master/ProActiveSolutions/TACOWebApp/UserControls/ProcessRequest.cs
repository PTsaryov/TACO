﻿namespace TACO.UI
{
    public delegate void ProcessRequest();
}