﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TACOData.Entities.POCOs
{
    public class SecurityRoleInformation
    {
        public int SecurityRoleId { get; set; }

        public string SecurityRole { get; set; }

        public string RoleDescription { get; set; }
    }
}
