﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TACOData.Entities.POCOs.TimeSheet
{
    public class StartEndWeekDay
    {
        public DateTime StartOfWeek { get; set; }
        public DateTime EndOfWeek { get; set; }
    }
}
