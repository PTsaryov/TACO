﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TACOData.Entities.POCOs.DaysOff
{
    public class DayOffIndicator
    {
        public List<KeyValuePair<int, string>> Flag { get; set; }
    }
}